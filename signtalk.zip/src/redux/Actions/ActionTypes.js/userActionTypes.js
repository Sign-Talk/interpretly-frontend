export const LOG_IN_USER = 'LOG_IN_USER'
export const REGISTER_USER = 'REGISTER_USER'
export const RESET_PASS = 'RESET_PASS'
export const IS_LOADING = 'IS_LOADING'
