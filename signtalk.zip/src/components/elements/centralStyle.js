const ModalLogin = {
  height: "455.33px",
  width: "600px",
  margin: "auto",
 backgroundColor:"transparent",
 
};
const Label ={ color: "white",fontSize:"13px" }

export const centralStyle = {
  ModalLogin,
  Label
};
