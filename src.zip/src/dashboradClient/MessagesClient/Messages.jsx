import React from "react";
import Navbar from "../Navbar/Navbar";

function Messages(props) {
  return (
    <div
      className="col-10 ml-auto c0 p-0"
      style={{
        Width: "44.271vw",
        position: "relative",
      }}
    >
      <Navbar title={"Messages"} />
    </div>
  );
}

export default Messages;
