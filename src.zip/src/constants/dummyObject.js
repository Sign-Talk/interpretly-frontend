const jobRequests=[
    {
        id:1,
        location:"state bank of india",
        address:"#769, GYR Chambers, Kaikondanhalli, Sarjapur Road, Bengaluru, Karnataka.",
        type:"Remote",
        requirement:"english Interpreter",
        price:"500/-",
        timeStamp:"16th Oct at 03:30PM",
        period:"2hours",
        category:"technology",
        accept:false,
        rating:[2,3,4,5],
        avgRating:4.3
    },
    {
        id:2,
        location:"Marathapalli police",
        address:"#769, GYR Chambers, Kaikondanhalli, Sarjapur Road, Bengaluru, Karnataka.",
        type:"Remote",
        requirement:"hindi Interpreter",
        price:"300/-",
        timeStamp:"16th Oct at 03:30PM",
        period:"2hours",
        category:"medical",
        accept:true,
        completed:true,
        rating:[2,3,4,5],
        avgRating:4.5

    }
]


