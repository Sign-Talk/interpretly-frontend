import { LOG_IN } from "../../ActionTypes/Interpreter/interpreterActionTypes";

export default logIn  = (interpreterData, history) => dispatch => {
    try {
        
    } catch (error) {
        
    }
}