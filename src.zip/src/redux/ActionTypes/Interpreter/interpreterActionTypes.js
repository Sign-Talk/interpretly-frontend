export const LOG_IN = 'LOG_IN'
export const EMAIL_VERIFY = 'EMAIL_VERIFY'
export const DASHBOARD = 'DASHBOARD'
