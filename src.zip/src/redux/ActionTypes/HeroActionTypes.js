export const SET_MODALSTATE = 'SET_MODALSTATE'
export const SET_CLICKED = 'SET_CLICKED'
export const SET_VERIFY = 'SET_VERIFY'