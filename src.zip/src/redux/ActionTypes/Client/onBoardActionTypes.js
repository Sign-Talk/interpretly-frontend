export const INPUT_ON_CHANGE = 'INPUT_ON_CHANGE'
export const LOG_MODAL = 'LOG_MODAL'
export const PHONE_MODAL = 'PHONE_MODAL'